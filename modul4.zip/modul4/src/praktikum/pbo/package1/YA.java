/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package praktikum.pbo.package1;
import Pack.DefaultModifier;
import Pack.PublicModifier;
import Pack.ProtectedModifier;
import Pack.ProvateModifier;
/**
 *
 * @author LAB-RPL
 */
public class YA {
    public static void main(String[] args){
        DefaultModifier Saya=new DefaultModifier();
        
        Saya.jumlah();
    
        PublicModifier kali1=new PublicModifier();
        
        kali1.kali();
        kali1.tambah();
        kali1.kurang();
        kali1.bagi();
        kali1.ratarata();
        
        ProtectedModifier lala=new ProtectedModifier();
        lala.printnfo();
        lala.sendMessage();
        
        ProvateModifier lulu=new ProvateModifier();
        
        lulu.printInfo();
    }
      
}
