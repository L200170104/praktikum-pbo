/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pack;

/**
 *
 * @author LAB-RPL
 */
public class PublicModifier {
    public int a=2;
    public int b=5;
    public int c=9;
    public void kali(){
        int d = a*b*c;
        System.out.println("Hasil kali = "+d);
    }
    public void tambah(){
        int f = a+b+c;
        System.out.println("Hasil jumlah = "+f);
    }
    public void kurang(){
        int g = a-b-c;
        System.out.println("Hasil kurang = "+g);
    }
    public void bagi(){
        int h = a/b/c;
        System.out.println("Hasil bagi = "+h);
    }
    public void ratarata(){
        int i = a+b+c/3;
        System.out.println("Hasil rata-rata = "+i);
    }
    
    public static void main(String[] args) {
        PublicModifier kali1=new PublicModifier();
        
        kali1.kali();
        kali1.tambah();
        kali1.kurang();
        kali1.ratarata();
        kali1.bagi();
    }
}

